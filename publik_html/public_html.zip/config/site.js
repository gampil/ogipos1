// Domain dan database publik mengikuti app/firebase-config.js dan admin-ogipos.
window.OGIPOS_PUBLIC_CONFIG = Object.freeze({
  registerUrl: "https://daftar.ogipos.com/",
  tenantBaseDomain: "ogipos.com",
  paymentUrl: "/bayar",
  lifetimePackageUrl: "https://gampilmedia-002-default-rtdb.firebaseio.com/ogipos_master/packages/lifetime.json",
  reservedSlugs: ["www", "app", "admin", "api", "mail", "webmail", "cpanel", "ftp", "daftar", "register", "signup", "static", "assets", "support", "help", "sukses"]
});
