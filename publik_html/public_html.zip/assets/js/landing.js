(function () {
  'use strict';
  const config = window.OGIPOS_PUBLIC_CONFIG;
  if (!config) return;
  const $ = id => document.getElementById(id), money = n => 'Rp ' + Number(n || 0).toLocaleString('id-ID');
  let lifetimePrice = null;
  function calculate() {
    if (!$('monthly-cost')) return;
    const monthly = Math.min(10000000, Math.max(0, Number($('monthly-cost').value) || 0));
    const years = Math.min(10, Math.max(1, Number($('cost-years').value) || 5)), total = monthly * 12 * years;
    $('years-label').textContent = years + ' tahun';
    document.querySelector('.calculator-heading h2').textContent = 'Berapa biaya aplikasi Anda dalam ' + years + ' tahun?';
    $('monthly-total').textContent = money(total); $('monthly-formula').textContent = money(monthly) + ' × ' + years * 12 + ' bulan';
    $('lifetime-total').textContent = lifetimePrice === null ? 'Lihat harga terkini' : money(lifetimePrice);
    $('cost-savings').textContent = lifetimePrice === null ? 'Menunggu harga Lifetime' : money(Math.max(0, total - lifetimePrice));
    if (lifetimePrice !== null && total < lifetimePrice) $('cost-savings').textContent = 'Belum lebih hemat pada periode ini';
  }
  async function price() {
    if (!$('package-price')) return;
    const abort = new AbortController(), timer = setTimeout(() => abort.abort(), 6000);
    try {
      const response = await fetch(config.lifetimePackageUrl, { cache: 'no-store', signal: abort.signal });
      if (!response.ok) throw new Error('Harga belum tersedia');
      const configured = await response.json(), data = configured || { name: 'OGIPOS Lifetime', price: 99000, type: 'lifetime' };
      if (data.type !== 'lifetime' || !Number.isInteger(Number(data.price)) || Number(data.price) < 2000 || Number(data.price) > 10000000) throw new Error('Harga belum tersedia');
      lifetimePrice = Number(data.price); $('package-price').textContent = money(lifetimePrice); $('package-name').textContent = data.name || 'OGIPOS Lifetime';
      $('package-caption').textContent = 'Sekali bayar · total QRIS dapat mencakup biaya pembayaran / kode unik.';
    } catch (_) { if (lifetimePrice === null) { $('package-price').textContent = 'Lihat saat aktivasi'; $('package-caption').textContent = 'Harga terkini ditampilkan di halaman aktivasi Owner sebelum Anda membayar.'; } }
    finally { clearTimeout(timer); calculate(); }
  }
  $('monthly-cost')?.addEventListener('input', calculate); $('cost-years')?.addEventListener('input', calculate);
  calculate(); price(); setInterval(() => { if (!document.hidden) price(); }, 60000);
  const normalize = text => String(text || '').trim().toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const form = $('tenantLoginForm');
  if (form) {
    const input = $('tenantSlug'), preview = $('tenantPreview'), message = $('tenantMessage');
    input.addEventListener('input', () => preview.textContent = (normalize(input.value) || 'namalaundry') + '.' + config.tenantBaseDomain);
    form.addEventListener('submit', event => {
      event.preventDefault(); const slug = normalize(input.value);
      if (!/^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/.test(slug) || config.reservedSlugs.includes(slug)) {
        message.textContent = 'Masukkan alamat laundry yang valid: 3–30 karakter, huruf, angka, atau tanda minus.'; message.classList.remove('hidden'); return;
      }
      const pay = location.pathname === '/bayar' || new URLSearchParams(location.search).get('next') === 'payment';
      location.assign('https://' + slug + '.' + config.tenantBaseDomain + (pay ? '/bayar' : '/'));
    });
  }
  if ($('registerRedirect')) { $('registerRedirect').href = config.registerUrl; location.replace(config.registerUrl); }
})();
