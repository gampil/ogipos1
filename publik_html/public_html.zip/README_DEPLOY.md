# Landing OGIPOS

Pasang isi folder pada host `ogipos.com`; jangan menggabungkannya dengan aplikasi tenant wildcard. Homepage adalah halaman SEO publik. Rute `/masuk`, `/daftar`, `/bayar`, `/lupa-password` menggunakan rewrite Apache `.htaccess` atau `_redirects` pada host statis yang mendukungnya. Untuk provider lain, buat aturan ekuivalen sebelum deploy. Harga Lifetime tetap dibaca dari RTDB dan harus cocok dengan panel admin; checkout sebenarnya ada di `https://{slug}.ogipos.com/bayar`.

`robots.txt` dan `sitemap.xml` hanya mengutamakan homepage; halaman pengarah masuk/daftar/bayar noindex. Konfigurasi host ada di `config/site.js`. Backend PHP dipasang pada shared hosting sesuai `../backend/README.md`; domain publik ini tidak menyimpan secret.
